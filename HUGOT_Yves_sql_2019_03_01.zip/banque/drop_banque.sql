drop table pret;
drop table compte;
drop table client;
SELECT table_name FROM user_tables;