--start D:\SQL\oracle\drop_banque;
start D:\SQL\oracle\install_banque;
start D:\SQL\oracle\install_data_banque;
start D:\SQL\oracle\req_banque;